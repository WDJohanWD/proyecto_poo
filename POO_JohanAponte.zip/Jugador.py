class Jugador:
    nombre: str
    
    def __init__(self, nombre:str):
        #Simplemente recibe el nombre del primer jugador
        
        
        self.nombre = nombre