from Trivial import Trivial

if __name__ == '__main__':
    trivial=Trivial
    
    trivial.trivial_main()